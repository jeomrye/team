package com.std.domain;

public interface MemDAO {

}
