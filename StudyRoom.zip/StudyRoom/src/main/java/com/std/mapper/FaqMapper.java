package com.std.mapper;

public interface FaqMapper {

}
