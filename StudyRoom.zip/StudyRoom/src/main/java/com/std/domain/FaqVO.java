package com.std.domain;

import java.util.Date;

import lombok.Data;

@Data
public class FaqVO {

	private Long faqno; //글번호
	
	private String title; //제목
	
	private String content; //내용
	
	private String writer; //작성자
	
	private Date writedate; //작성일
	
	private int readcnt; //조회수
	
	private String userid; //작성자 아이디
}
