package com.std.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.std.domain.Criteria;
import com.std.domain.FaqVO;
import com.std.mapper.FaqMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class FaqServiceImpl implements FAQService {

	@Setter(onMethod_ = @Autowired)
	public FaqMapper mapper;

	@Override
	public void register(FaqVO faq) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FaqVO get(Long faqNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modify(FaqVO faq) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Long faqNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<FaqVO> getList(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotal(Criteria cri) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
